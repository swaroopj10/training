package com.fidelity.weather.restcontroller;

class WeatherControllerPojoUnitTest {

}
